export{default as anime}from"animejs";
